from django.db import models

# Create your models here.

class login (models.Model):
    username=models.CharField(max_length=30)
    password=models.CharField(max_length=30)
    type=models.CharField(max_length=30)
    status=models.IntegerField()


class  cregistration (models.Model):
    cid = models.AutoField(max_length=50, primary_key=True)
    fname=models.CharField(max_length=30)
    lname=models.CharField(max_length=30)
    mailid=models.EmailField(max_length=30)
    address=models.TextField(max_length=50)
    phonenumber=models.BigIntegerField()
    paswd=models.CharField(max_length=30)
    image=models.ImageField(upload_to='image')
    logid=models.ForeignKey(login,on_delete=models.CASCADE)




class rest (models.Model):
    resid=models.AutoField(max_length=50,primary_key=True)
    resname=models.CharField(max_length=30)
    city=models.CharField(max_length=20)
    image=models.CharField(max_length=30)
    email=models.CharField(max_length=20)
    mobile=models.BigIntegerField()
    landline=models.CharField(max_length=12)
    password=models.CharField(max_length=20)
    address=models.CharField(max_length=30)
    regno=models.CharField(max_length=20)
    gstno=models.CharField(max_length=20)
    logid=models.ForeignKey(login,on_delete=models.CASCADE)
