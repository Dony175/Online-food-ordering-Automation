from django.conf.urls import url

from food import views

urlpatterns = [
    url('home', views.home, name='home'),
    url('login', views.login, name='login'),
    url('registration', views.registration, name='registration'),
    url('productadd', views.productadd, name='productadd'),
    url('checkout', views.checkout, name='checkout'),
    url('resregistration', views.resregistration, name='resregistration'),
    url('restaurants', views.restaurants, name='restaurants'),
    url('log', views.log, name='log'),




]