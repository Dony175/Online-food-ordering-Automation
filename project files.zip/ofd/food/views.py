from django.http import HttpResponse
from django.shortcuts import render
from django.template import loader

from .models import cregistration, login, rest


# Create your views here.
def home(request):
    return render(request,"index.html")


def loginform(request):
    return render(request, "login.html")

def registration(request):
    return render(request, "registration.html")

def restaurants(request):
    return render(request, "restaurants.html")

def checkout(request):
    return render(request, "checkout.html")

def resregistration(request):
    return render(request, "resregistration.html")

def productadd(request):
    return render(request, "productadd.html")

def add(request):
    if request.method=='POST':
        fname = request.POST.get('firstname')
        lname= request.POST.get('lastname')
        mailid = request.POST.get('emailid')
        address = request.POST.get('address')
        phonenumber = request.POST.get('phonenumber')
        password = request.POST.get('password')
        image = request.FILES['image']
        obj1=login()
        obj1.username=mailid
        obj1.password=password
        obj1.type='customer'
        obj1.status=0
        obj1.save()
        obj=cregistration()
        obj.fname=fname
        obj.lname=lname
        obj.mailid=mailid
        obj.address=address
        obj.phonenumber=phonenumber
        obj.paswd=password
        obj.image=image
        obj.logid=obj1
        obj.save()
        return  render(request,'login.html')
    else:
        return render(request,'registration.html')


def res(request):
    if request.method=='POST':
        resname = request.POST.get('resname')
        city = request.POST.get('city')
        email = request.POST.get('email')
        address = request.POST.get('address')
        mobile = request.POST.get('mobile')
        landline = request.POST.get('landline')
        regno = request.POST.get('regno')
        gstno = request.POST.get('gstno')
        password = request.POST.get('password')
        image = request.FILES['image']
        obj2=login()
        obj2.username=email
        obj2.password = password
        obj2.type='restaurant'
        obj2.status=1
        obj2.save()
        obj= rest()
        obj.resname=resname
        obj.city = city
        obj.email=email
        obj.address=address
        obj.mobile=mobile
        obj.landline = landline
        obj.regno = regno
        obj.gstno = gstno
        obj.password=password
        obj.image=image
        obj.logid=obj2
        obj.save()
        return  render(request,'login.html')
    else:
        return render(request,'registration.html')

def log(request):
        if request.method=='POST':
         username=request.POST.get('username')
         password=request.POST.get('password')
        if(login.objects.filter(username=username, password=password).exists()):
            logins=login.objects.filter(username=username,password=password)
            for value in logins:
                user_id=value.id
                usertype=value.type
                ustatus=value.status
                if usertype=='customer' and ustatus==0:
                    Role=request.session['userRole']='customer'
                    return render(request,'index.html',{'user':Role,'id':user_id})
                elif usertype=='admin':
                    Role=request.session["userRole"]='Admin'
                    return render(request,'admin/admin.html',{'user':Role})
                else:
                    context={"error":"incorrect username or password"}
                    return render(request,"login.html",context)
            else:
                template=loader.get_template("login.html")
                context={"error":"incorrect information"}
                return HttpResponse(template.render(context,request))
        else:
            template=loader.get_template("login.html")
            context={}
            return HttpResponse(template.render(context,request))






