"""ofd URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from django.urls import path, include

from food import views
from food.views import registration

urlpatterns = [

    url('admin1/', include('food.url')),
    url(r'^registration/',views.registration,name='registration'),
    url(r'^home/',views.home,name='home'),
    url(r'^login/', views.loginform, name='login'),
    url(r'^checkout/', views.checkout, name='checkout'),
    url(r'^resregistration/', views.resregistration, name='resregistration'),
    url(r'^restaurants/', views.restaurants, name='restaurants'),
    url(r'^add/', views.add, name='add'),
    url(r'^productadd/', views.productadd, name='productadd'),
    url(r'^res/', views.res, name='res'),
    url(r'^signin/', views.log, name='log'),


]

